import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { BehaviorSubject, catchError, map, Observable, tap, throwError } from 'rxjs';
import { environment } from '../../environments/environment';

export interface AuthUser {
  id:                 number;
  name:               string;
  email:              string;
  phone?:             string;
  stripe_customer_id?: string;
}

export interface LoginPayload {
  email:    string;
  password: string;
}

export interface RegisterPayload {
  name:                  string;
  email:                 string;
  password:              string;
  password_confirmation?: string;
  phone?:                string;
}

export interface AuthResponse {
  user:  AuthUser;
  token: string;
}

const TOKEN_KEY = 'auth_token';
const USER_KEY  = 'auth_user';

@Injectable({
  providedIn: 'root',
})

export class AuthService {
  private readonly http   = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly base   = `${environment.apiUrl}/auth`;

  // ─── Reactive state ──────────────────────────────────────────

  private readonly _currentUser$ = new BehaviorSubject<AuthUser | null>(
    this.loadUserFromStorage(),
  );

  /** Emits the current user or null when logged out. */
  readonly currentUser$: Observable<AuthUser | null> = this._currentUser$.asObservable();

  /** Emits true when authenticated — used by authGuard. */
  readonly isAuthenticated$: Observable<boolean> = this._currentUser$.pipe(
    map(user => !!user),
  );

  // ─── Synchronous getters (used by existing app code) ─────────

  get currentUser(): AuthUser | null {
    return this._currentUser$.value;
  }

  get token(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  /**
   * Synchronous auth check.
   * Used as: auth.isLoggedIn() in templates and components.
   */
  isLoggedIn(): boolean {
    return !!this._currentUser$.value && !!localStorage.getItem(TOKEN_KEY);
  }

  /**
   * Returns the stored user synchronously.
   * Used as: auth.getStoredUser() in profile and other pages.
   */
  getStoredUser(): AuthUser | null {
    return this._currentUser$.value;
  }

  // ─── Session helpers (used by existing login/register pages) ─

  /**
   * Persists the auth response after login or register.
   * Used as: auth.storeAuth(res)
   */
  storeAuth(res: AuthResponse): void {
    this.persistSession(res);
  }

  /**
   * Listens for the browser back button and clears the session
   * if the user is no longer logged in.
   * Used as: auth.initBackButtonLogout()
   */
  initBackButtonLogout(): void {
    window.addEventListener('popstate', () => {
      if (!this.isLoggedIn()) {
        this.clearSession(true);
      }
    });
  }

  // ─── Auth actions ─────────────────────────────────────────────

  login(payload: LoginPayload): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.base}/login`, payload).pipe(
      tap(res => this.persistSession(res)),
      catchError(err => throwError(() => err)),
    );
  }

  register(payload: RegisterPayload): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.base}/register`, payload).pipe(
      tap(res => this.persistSession(res)),
      catchError(err => throwError(() => err)),
    );
  }

  logout(redirectToLogin = true): void {
    this.http.post(`${this.base}/logout`, {}).pipe(
      catchError(() => throwError(() => null)),
    ).subscribe({
      complete: () => this.clearSession(redirectToLogin),
      error:    () => this.clearSession(redirectToLogin),
    });
  }

  /**
   * Re-fetches and validates the stored token against the API.
   * Called by the app initializer on cold start.
   */
  fetchCurrentUser(): Observable<AuthUser> {
    return this.http.get<AuthUser>(`${this.base}/me`).pipe(
      tap(user => {
        this._currentUser$.next(user);
        localStorage.setItem(USER_KEY, JSON.stringify(user));
      }),
      catchError(err => {
        this.clearSession(false);
        return throwError(() => err);
      }),
    );
  }

  // ─── Private helpers ──────────────────────────────────────────

  private persistSession(res: AuthResponse): void {
    localStorage.setItem(TOKEN_KEY, res.token);
    localStorage.setItem(USER_KEY, JSON.stringify(res.user));
    this._currentUser$.next(res.user);
  }

  private clearSession(redirect: boolean): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    this._currentUser$.next(null);
    if (redirect) {
      this.router.navigate(['/login']);
    }
  }

  private loadUserFromStorage(): AuthUser | null {
    try {
      const raw = localStorage.getItem(USER_KEY);
      return raw ? (JSON.parse(raw) as AuthUser) : null;
    } catch {
      return null;
    }
  }
}


/*import { CommonModule } from '@angular/common';
import { Component, inject, Injectable, OnInit } from '@angular/core';
import { FormBuilder, NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { TitheService } from '../../services/tithe.service';
import { CreateTitheDto } from '../../models/create-tithe.dto';
import { Tithe } from '../../models/tithe.model';

@Component({
  selector: 'app-tithe',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './tithe.html',
  styleUrls: ['./tithe.css'],
})
export class TitheComponent implements OnInit {

  private fb = inject(NonNullableFormBuilder);

  tithes: Tithe[] = [];
  loading = false;
  successMessage = '';
  errorMessage = '';
  selectedAmount: number | null = null;

  titheForm = this.fb.group({
    giver_name: ['', Validators.required],
    giver_email: [''],
    giver_phone: ['', [Validators.required, Validators.pattern(/^0[17]\d{8}$/)]],
    amount: [0, [Validators.required, Validators.min(1)]],
    currency: ['KES', Validators.required],
    payment_method: ['mpesa'],
  });

  constructor(private titheService: TitheService) {}

  ngOnInit(): void {
    this.loadTithes();
  }

  loadTithes(): void {
    this.titheService.getTithes().subscribe({
      next: (res: Tithe[]) => {
        this.tithes = res;
      },
      error: (err) => {
        console.error('Error fetching tithes', err);
      }
    });
  }

  submit(): void {
    if (this.titheForm.invalid) {
      this.titheForm.markAllAsTouched();
      return;
    }

    this.loading = true;

    const payload: CreateTitheDto = this.titheForm.getRawValue();

    this.titheService.createTithe(payload).subscribe({
     next: () => {
      this.successMessage = 'Tithe submitted successfully.';
      this.titheForm.reset({
        giver_name: '',
        giver_email: '',
        giver_phone: '',
        amount: 0,
        currency: 'KES',
        payment_method: 'mpesa'
      });
      this.loadTithes();
      this.loading = false;
     },
     error: (err) => {
      console.error('Error creating tithe', err);
      this.loading = false;
     }
    });
  }

  selectAmount(amount: number): void {
      this.titheForm.patchValue({ amount});
    }
}*/

// src/app/features/tithe/components/tithe-payment/tithe-payment.component.ts

// src/app/features/tithe/components/tithe-payment/tithe-payment.component.ts

import {
  Component, OnInit, OnDestroy, inject, signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  ReactiveFormsModule, FormBuilder, FormGroup,
  Validators, AbstractControl, ValidationErrors,
} from '@angular/forms';
import { Subject, takeUntil } from 'rxjs';

import { TitheService } from '../../services/tithe.service';
import { AuthService } from '../../services/auth';
import { MpesaInitiateResponse, PaymentStep } from '../../models/tithe.model';

// Kenyan phone validator
function kenyanPhoneValidator(control: AbstractControl): ValidationErrors | null {
  if (!control.value) return null;
  const pattern = /^(?:\+?254|0)[17]\d{8}$/;
  return pattern.test(control.value.replace(/\s/g, ''))
    ? null
    : { invalidPhone: true };
}

@Component({
  selector: 'app-tithe-payment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './tithe.html',
  styleUrls: ['./tithe.css'],
})
export class TithePaymentComponent implements OnInit, OnDestroy {
  private readonly titheService = inject(TitheService);
  private readonly authService  = inject(AuthService);
  private readonly fb           = inject(FormBuilder);
  private readonly destroy$     = new Subject<void>();
  private readonly stopPoll$    = new Subject<void>();

  // ─── State signals ────────────────────────────────────────────

  readonly isAuthenticated = signal(false);
  readonly currentUser     = signal<any>(null);
  readonly step            = signal<PaymentStep>('form');
  readonly isSubmitting    = signal(false);
  readonly errorMessage    = signal<string | null>(null);

  // Result signals
  readonly mpesaReference  = signal<string | null>(null);
  readonly receipt         = signal<string | null>(null);
  readonly paidAmount      = signal<number>(0);

  // ─── Quick amounts ────────────────────────────────────────────

  readonly quickAmounts = [500, 1000, 2000, 5000, 10000];

  // ─── Form ─────────────────────────────────────────────────────

  form!: FormGroup;

  // ─── Lifecycle ────────────────────────────────────────────────

  ngOnInit(): void {
    this.initForm();

    this.authService.currentUser$
      .pipe(takeUntil(this.destroy$))
      .subscribe(user => {
        this.currentUser.set(user);
        this.isAuthenticated.set(!!user);
        this.updateValidators();
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    this.stopPoll$.next();
    this.stopPoll$.complete();
  }

  // ─── Form setup ───────────────────────────────────────────────

  private initForm(): void {
    this.form = this.fb.group({
      amount:   [null, [Validators.required, Validators.min(1)]],
      phone:    ['', [Validators.required, kenyanPhoneValidator]],
      fullName: [''],
      email:    [''],
    });
  }

  private updateValidators(): void {
    const fullName = this.form.get('fullName')!;
    const email    = this.form.get('email')!;

    fullName.clearValidators();
    email.clearValidators();

    if (!this.isAuthenticated()) {
      fullName.setValidators([Validators.required, Validators.minLength(3)]);
    }

    fullName.updateValueAndValidity();
    email.updateValueAndValidity();
  }

  // ─── Quick amount ─────────────────────────────────────────────

  selectQuickAmount(amount: number): void {
    this.form.get('amount')?.setValue(amount);
  }

  // ─── Submit ───────────────────────────────────────────────────

  async onSubmit(): Promise<void> {
    if (this.form.invalid || this.isSubmitting()) return;
    this.errorMessage.set(null);
    await this.submitMpesa();
  }

  // ─── M-Pesa flow ──────────────────────────────────────────────

  private async submitMpesa(): Promise<void> {
    this.isSubmitting.set(true);

    const user    = this.currentUser();
    const formVal = this.form.value;

    const payload: any = {
      amount: formVal.amount,
      phone:  formVal.phone,
    };

    if (!user) {
      payload.full_name = formVal.fullName;
      if (formVal.email) payload.email = formVal.email;
    }

    this.titheService.initiateMpesa(payload)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res: MpesaInitiateResponse) => {
          this.isSubmitting.set(false);
          this.mpesaReference.set(res.reference);
          this.paidAmount.set(formVal.amount);
          this.step.set('processing');
          this.startMpesaPolling(res.reference);
        },
        error: (err) => {
          this.isSubmitting.set(false);
          this.errorMessage.set(
            err.error?.message ?? 'Failed to initiate M-Pesa payment. Please try again.',
          );
        },
      });
  }

  private startMpesaPolling(reference: string): void {
    this.titheService.pollMpesaStatus(reference, this.stopPoll$)
      .subscribe({
        next: (status) => {
          if (status.status === 'completed') {
            this.receipt.set(status.receipt);
            this.step.set('success');
          } else {
            this.errorMessage.set('Payment was not completed. Please try again.');
            this.step.set('failed');
          }
        },
        error: () => {
          this.errorMessage.set('Could not verify payment status. Please contact support.');
          this.step.set('failed');
        },
      });
  }

  cancelMpesaPolling(): void {
    this.stopPoll$.next();
    this.step.set('form');
  }

  // ─── Reset ────────────────────────────────────────────────────

  reset(): void {
    this.form.reset();
    this.step.set('form');
    this.errorMessage.set(null);
    this.mpesaReference.set(null);
    this.receipt.set(null);
    this.stopPoll$.next();
  }
}
